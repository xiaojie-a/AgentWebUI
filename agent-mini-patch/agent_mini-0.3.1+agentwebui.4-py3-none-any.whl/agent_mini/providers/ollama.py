"""Ollama provider — local models via Ollama API."""

from __future__ import annotations

import json
import re
from typing import Any

import httpx

from .base import (
    BaseProvider,
    ChatResponse,
    StreamCallback,
    parse_openai_tool_calls,
)

# [AgentWebUI patch] lfm2.5 等模型的模板会把思考以 <think>…</think> 写在正文流里
# （不遵守 think 参数），需要增量剥离，避免思考标签/内容污染回答。
_THINK_OPEN = "<think>"
_THINK_CLOSE = "</think>"
_THINK_BLOCK_RE = re.compile(r"<think>.*?</think>", re.S)


def _strip_think_final(text: str) -> str:
    """兜底清洗：移除 <think>…</think> 与未闭合残留（用于非流式/收尾）。"""
    if not text:
        return text
    text = _THINK_BLOCK_RE.sub("", text)
    if _THINK_OPEN in text:
        text = text.split(_THINK_OPEN, 1)[0]
    text = text.replace(_THINK_CLOSE, "").replace(_THINK_OPEN, "")
    return text


class OllamaProvider(BaseProvider):
    """Connect to a running Ollama instance.

    Ollama exposes ``/api/chat`` with tool-calling, thinking, and streaming.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str = "llama3.1",
        think: bool | str | None = None,
        num_ctx: int | None = None,
    ):
        self._base_url = base_url.rstrip("/")
        self._model = model
        self._think = think
        self._num_ctx = num_ctx
        self._client = httpx.AsyncClient(timeout=300)

    async def close(self) -> None:
        await self._client.aclose()

    @property
    def name(self) -> str:
        return "ollama"

    @property
    def model_name(self) -> str:
        return self._model

    async def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        temperature: float = 0.7,
    ) -> ChatResponse:
        payload = self._build_payload(
            messages, tools=tools, temperature=temperature, stream=False
        )
        resp = await self._client.post(f"{self._base_url}/api/chat", json=payload)
        resp.raise_for_status()
        return self._extract_chat_response(resp.json())

    async def chat_stream(
        self,
        messages: list[dict],
        on_delta: StreamCallback,
        tools: list[dict] | None = None,
        temperature: float = 0.7,
        on_thinking: StreamCallback | None = None,
    ) -> ChatResponse:
        payload = self._build_payload(
            messages, tools=tools, temperature=temperature, stream=True
        )

        content_parts: list[str] = []
        thinking_parts: list[str] = []
        last_message: dict[str, Any] = {}
        tool_calls_raw: list[dict] | None = None
        # [精确Token] 记录流式响应中的真实 token 计数（最后一个 done chunk 携带）
        _prompt_eval_count = 0
        _eval_count = 0

        # [AgentWebUI patch] 增量剥离 <think>…</think>（标签可能跨 chunk 分片）
        pending = ""
        in_think = False
        # 思考分块合并：Ollama chunk 极碎，攒够一段再回调 on_thinking，减少前端抖动
        think_buf: list[str] = []
        think_len = 0
        _THINK_CHUNK = 160

        async def _flush_think_buf():
            nonlocal think_buf, think_len
            if think_buf and on_thinking:
                text = "".join(think_buf)
                think_buf = []
                think_len = 0
                await on_thinking(text)

        async with self._client.stream(
            "POST",
            f"{self._base_url}/api/chat",
            json=payload,
        ) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line:
                    continue
                try:
                    chunk = json.loads(line)
                except json.JSONDecodeError:
                    continue

                message = chunk.get("message") or {}
                if message:
                    last_message = message

                # [精确Token] 从 chunk 中提取真实 token 计数（通常在最后一个 done chunk 中）
                if chunk.get("prompt_eval_count"):
                    _prompt_eval_count = chunk["prompt_eval_count"]
                if chunk.get("eval_count"):
                    _eval_count = chunk["eval_count"]

                delta = message.get("content") or ""
                if not delta:
                    thinking_delta = message.get("thinking") or ""
                    if thinking_delta:
                        thinking_parts.append(thinking_delta)
                        if on_thinking:
                            await on_thinking(thinking_delta)
                    if message.get("tool_calls"):
                        tool_calls_raw = message["tool_calls"]
                    continue

                pending += delta
                # 解析当前 buffer：<think> 内容丢弃（转 thinking），其余作为正文
                while pending:
                    if in_think:
                        ci = pending.find(_THINK_CLOSE)
                        if ci == -1:
                            # </think> 可能被截断在尾部：先留出最长闭合标签前缀长度
                            hold = min(len(_THINK_CLOSE) - 1, len(pending))
                            if len(pending) > hold:
                                seg = pending[:-hold]
                                thinking_parts.append(seg)
                                think_buf.append(seg)
                                think_len += len(seg)
                                if think_len >= _THINK_CHUNK:
                                    await _flush_think_buf()
                            pending = pending[-hold:] if hold else ""
                            break
                        head = pending[:ci]
                        if head:
                            thinking_parts.append(head)
                            think_buf.append(head)
                            think_len += len(head)
                            if think_len >= _THINK_CHUNK:
                                await _flush_think_buf()
                        in_think = False
                        await _flush_think_buf()   # 一段思考结束：把残留整段送达
                        pending = pending[ci + len(_THINK_CLOSE):]
                        continue
                    oi = pending.find(_THINK_OPEN)
                    if oi == -1:
                        hold = min(len(_THINK_OPEN) - 1, len(pending))
                        if len(pending) > hold:
                            safe = pending[:-hold]
                            content_parts.append(safe)
                            await on_delta(safe)
                            pending = pending[-hold:]
                        break
                    before = pending[:oi]
                    if before:
                        content_parts.append(before)
                        await on_delta(before)
                    in_think = True
                    pending = pending[oi + len(_THINK_OPEN):]

                if message.get("tool_calls"):
                    tool_calls_raw = message["tool_calls"]

        # 收尾：残留 tail（正常正文 / 未闭合思考）
        if pending:
            if in_think:
                thinking_parts.append(pending)
                think_buf.append(pending)
            else:
                safe = pending
                if _THINK_OPEN in safe or _THINK_CLOSE in safe:
                    safe = _strip_think_final(safe)
                if safe:
                    content_parts.append(safe)
                    await on_delta(safe)
        await _flush_think_buf()  # 兜底：未闭合思考的残留也送达

        content = "".join(content_parts) or (last_message.get("content") or None)
        content = _strip_think_final(content or "") or None
        thinking = "".join(thinking_parts) or (last_message.get("thinking") or None)
        tool_calls = parse_openai_tool_calls(
            tool_calls_raw or last_message.get("tool_calls")
        )
        # [精确Token] 构造真实 usage（流式响应中提取的 prompt_eval_count / eval_count）
        _usage = None
        if _prompt_eval_count or _eval_count:
            _usage = {
                "prompt_tokens": _prompt_eval_count,
                "completion_tokens": _eval_count,
                "total_tokens": _prompt_eval_count + _eval_count,
            }
        return ChatResponse(content=content, tool_calls=tool_calls, thinking=thinking, usage=_usage)

    def _build_payload(
        self,
        messages: list[dict],
        tools: list[dict] | None,
        temperature: float,
        stream: bool,
    ) -> dict:
        payload: dict = {
            "model": self._model,
            "messages": self._clean_messages(messages),
            "stream": stream,
            "options": {"temperature": temperature},
        }
        # [AgentWebUI patch] 显式传递上下文窗口上限（config providers.*.numCtx）
        if self._num_ctx:
            payload["options"]["num_ctx"] = int(self._num_ctx)
        if tools:
            payload["tools"] = tools
        if self._think not in (None, ""):
            payload["think"] = self._think
        return payload

    @staticmethod
    def _extract_chat_response(data: dict) -> ChatResponse:
        msg = data.get("message", {})
        usage = None
        if data.get("prompt_eval_count") or data.get("eval_count"):
            usage = {
                "prompt_tokens": data.get("prompt_eval_count", 0),
                "completion_tokens": data.get("eval_count", 0),
                "total_tokens": (
                    data.get("prompt_eval_count", 0) + data.get("eval_count", 0)
                ),
            }
        return ChatResponse(
            content=_strip_think_final(msg.get("content") or "") or None,
            tool_calls=parse_openai_tool_calls(msg.get("tool_calls")),
            thinking=msg.get("thinking") or None,
            usage=usage,
        )

    @staticmethod
    def _clean_messages(messages: list[dict]) -> list[dict]:
        """Ollama expects a flat message list; convert tool results.

        Also translates OpenAI-style vision content parts
        (``[{"type": "image_url", "image_url": {"url": "..."}}, ...]``)
        into Ollama's flat ``images: ["<base64>"]`` field on the message,
        so vision works on the default provider.
        """
        cleaned = []
        for msg in messages:
            if msg["role"] == "tool":
                # Convert tool results for compatibility with older Ollama builds.
                cleaned.append(
                    {
                        "role": "user",
                        "content": (
                            f"[Tool result for {msg.get('name', 'tool')}]:\n"
                            f"{msg['content']}"
                        ),
                    }
                )
                continue

            base = {k: v for k, v in msg.items() if k != "tool_calls"}
            content = base.get("content")

            # OpenAI-style multi-part content → Ollama flat {content, images}.
            if isinstance(content, list):
                texts: list[str] = []
                images: list[str] = []
                for part in content:
                    if not isinstance(part, dict):
                        continue
                    if part.get("type") == "text":
                        texts.append(part.get("text", ""))
                    elif part.get("type") == "image_url":
                        url = (part.get("image_url") or {}).get("url", "")
                        # Ollama's `images` accepts either a raw base64 string
                        # or a URL. Strip the `data:...;base64,` prefix if
                        # present so it works with older builds too.
                        if url.startswith("data:") and ";base64," in url:
                            url = url.split(";base64,", 1)[1]
                        if url:
                            images.append(url)
                base["content"] = "\n".join(t for t in texts if t)
                if images:
                    base["images"] = images
            cleaned.append(base)
        return cleaned
