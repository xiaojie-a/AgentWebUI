"""Core agent loop — think → act → observe → repeat."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import random
import time
from dataclasses import dataclass
from typing import Awaitable, Callable

import httpx

from ..providers.base import BaseProvider
from .context import build_system_prompt
from .memory import Memory
from .token_estimator import (
    classify_model_tier,
    estimate_messages_tokens,
    get_effective_context,
    get_output_limit,
    get_tier_max_iterations,
)
from .tools import ToolExecutor
from .vision import build_image_content_parts

log = logging.getLogger("agent-mini")
StreamEmitter = Callable[[str], Awaitable[None]]

# HTTP status codes considered transient (worth retrying)
_TRANSIENT_CODES = {429, 500, 502, 503, 504}


def _as_pos_int(value) -> int:
    """[AgentWebUI patch] 把配置值安全转成正整数；非法/缺失/非正数返回 0。"""
    try:
        n = int(value)
    except (TypeError, ValueError):
        return 0
    return n if n > 0 else 0


def _as_ratio(value, default: float) -> float:
    """[AgentWebUI patch] 把配置值限制为 (0, 1] 比例；非法/缺失返回默认值。"""
    try:
        r = float(value)
    except (TypeError, ValueError):
        return default
    return r if 0 < r <= 1 else default


@dataclass
class ToolEvent:
    """Emitted when a tool is called or produces a result."""
    name: str
    arguments: dict | None = None
    result_preview: str | None = None
    is_error: bool = False
    duration: float = 0.0


ToolEventCallback = Callable[[ToolEvent], Awaitable[None]]


class AgentLoop:
    """Runs the agentic ReAct loop.

    1. Build messages (system + history + user message).
    2. Call the LLM.
    3. If the LLM returns tool calls → execute them, append results, goto 2.
    4. If the LLM returns text → return it to the caller.
    """

    def __init__(
        self,
        provider: BaseProvider,
        config: dict,
        memory: Memory,
    ):
        self.provider = provider
        self.config = config
        self.memory = memory
        self.tools = ToolExecutor(config, memory)
        self._model_name: str = provider.model_name
        self._model_tier: str = classify_model_tier(self._model_name)
        # [AgentWebUI patch] 有效上下文优先读当前 provider 的 numCtx 配置，
        # 让前端"上下文最大值"滑杆与后端压缩触发点真正联动；
        # 未配置 numCtx 时才回退到按模型档位估算的默认值。
        self._effective_ctx: int = self._resolve_effective_ctx()
        # [AgentWebUI patch] 压缩比例可配置（默认沿用官方 0.75 触发 / 0.5 目标）
        _agent_cfg = config.get("agent", {}) or {}
        self._compact_ratio: float = _as_ratio(_agent_cfg.get("compactRatio"), 0.75)
        self._compact_target_ratio: float = _as_ratio(
            _agent_cfg.get("compactTargetRatio"), 0.5
        )
        self._output_limit: int = get_output_limit(self._model_name)
        # Max iterations: respect explicit user config, otherwise use tier default
        user_iters = config.get("agent", {}).get("maxIterations")
        self.max_iterations: int = (
            user_iters if user_iters is not None
            else get_tier_max_iterations(self._model_name)
        )
        self.temperature: float = config.get("agent", {}).get("temperature", 0.7)
        # Token/cost tracking per session
        self.session_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        self.turn_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        # [AgentWebUI patch] 最近一次上下文压缩的结果（供 bridge 透出前端）；
        # run() 开头重置，避免把上一轮的压缩信息重复播报。
        self.last_compaction = None
        # Loop detection state
        self._recent_calls: list[str] = []

    def _resolve_effective_ctx(self) -> int:
        """[AgentWebUI patch] 解析"有效上下文"预算（触发压缩的基准）。

        优先级：
          1. 当前 provider 的 numCtx —— config["providers"][config["provider"]]["numCtx"]
          2. 任一 provider 的 numCtx（config["provider"] 缺失/不认识时的兜底）
          3. 按模型档位估算的默认值（官方原行为）

        这样前端把滑杆写入 config.numCtx 后，后端压缩阈值
        （effective_ctx * compactRatio）随之联动，无需改代码或重启进程——
        每次任务由 bridge 重新 load_config() 并新建 AgentLoop。
        """
        providers = self.config.get("providers") or {}
        name = self.config.get("provider")
        cfg = providers.get(name) if isinstance(providers.get(name), dict) else None
        if not cfg:
            for cand in providers.values():
                if isinstance(cand, dict) and _as_pos_int(cand.get("numCtx")):
                    cfg = cand
                    break
        n = _as_pos_int(cfg.get("numCtx")) if cfg else 0
        if n > 0:
            return n
        return get_effective_context(self._model_name)

    async def close(self) -> None:
        """Clean up provider and tool resources."""
        await self.provider.close()
        await self.tools.close()

    async def run(
        self,
        user_message: str,
        conversation: list[dict],
        on_stream: StreamEmitter | None = None,
        on_tool_event: ToolEventCallback | None = None,
        on_thinking=None,   # [AgentWebUI patch] 深度思考流式回调（<think> 剥离后逐段回调）
    ) -> str:
        """Process *user_message* and return the assistant's final text reply.

        *conversation* is mutated in-place (appended with the new user/assistant
        turns) so the caller can maintain session state.
        When *on_stream* is provided, partial text deltas are emitted in real time.
        """
        tool_defs = self.tools.get_tool_defs()
        system_prompt = build_system_prompt(
            self.config,
            self.memory,
            model_name=self._model_name,
            tool_defs=tool_defs,
        )

        # [AgentWebUI patch] 系统提示 token 估算，供 WebUI 上下文圆环"系统提示"分段显示。
        # 系统提示是调用时临时拼进 messages 的，从不以消息形式存入会话，前端无法从
        # 会话消息统计它；这里用与前端 estimateTokens 同款的 CJK 公式（cjk*0.7 + 其余/4）
        # 算出估算值，随 done 事件带回。真实占用量由 last_prompt_tokens 兜底。
        try:
            _cjk = sum(
                1 for _ch in system_prompt
                if "\u4e00" <= _ch <= "\u9fff"
                or "\u3040" <= _ch <= "\u30ff"
                or "\uac00" <= _ch <= "\ud7af"
            )
            self._system_prompt_tokens = max(
                0, round(_cjk * 0.7 + (len(system_prompt) - _cjk) / 4)
            )
        except Exception:
            self._system_prompt_tokens = 0

        # Reset per-turn usage tracking
        self.turn_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        # [AgentWebUI patch] 重置上一轮的压缩记录，避免重复播报
        self.last_compaction = None

        # Build the full message list for this request
        messages: list[dict] = [{"role": "system", "content": system_prompt}]
        messages.extend(conversation)

        # Build user message — detect image references for vision support
        image_parts = build_image_content_parts(user_message)
        if image_parts:
            messages.append({"role": "user", "content": image_parts})
        else:
            messages.append({"role": "user", "content": user_message})

        for iteration in range(self.max_iterations):
            log.debug("iteration %d / %d", iteration + 1, self.max_iterations)

            # Prune old tool results in-memory before sending to provider
            pruned = self._prune_tool_results(messages)

            response = await self._call_provider_with_retry(
                pruned, tool_defs, on_stream, on_thinking
            )
            if isinstance(response, str):
                # Error string from retry exhaustion
                return response

            # Accumulate token usage if available
            if hasattr(response, "usage") and response.usage:
                for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
                    val = response.usage.get(key, 0)
                    self.turn_usage[key] += val
                    self.session_usage[key] += val

            # ----- text-only response → done -----
            if not response.tool_calls:
                final = response.content or "(empty response)"
                # Persist to conversation history
                conversation.append({"role": "user", "content": user_message})
                conversation.append({"role": "assistant", "content": final})
                # Token-aware compaction: summarize when conversation
                # exceeds compactRatio (默认 75%) of the effective context
                # budget. [AgentWebUI patch] 比例与预算均可配置。
                current_tokens = estimate_messages_tokens(conversation)
                _threshold = int(self._effective_ctx * self._compact_ratio)
                if current_tokens > _threshold:
                    # [AgentWebUI patch] 记录压缩结果并附上阈值/触发量，
                    # 供 bridge 透出前端显示"压缩后占比"。
                    _info = await self._summarize_history(conversation)
                    if _info is not None:
                        _info["threshold"] = _threshold
                        _info["trigger_tokens"] = current_tokens
                        # [AgentWebUI patch] prompt_est_tokens：用估算器同一把尺子量的整条
                        # prompt（系统提示 + 会话）。bridge 靠它把"压缩后"从估算尺度折算
                        # 回模型真实 token 尺度（估算器是 len//4，与真实分词器有偏差）。
                        _info["prompt_est_tokens"] = estimate_messages_tokens(
                            [{"role": "system", "content": system_prompt}]
                        ) + current_tokens
                    self.last_compaction = _info
                return final

            # ----- tool calls → execute in parallel and continue -----
            assistant_msg: dict = {
                "role": "assistant",
                "content": response.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": (
                                json.dumps(tc.arguments)
                                if isinstance(tc.arguments, dict)
                                else tc.arguments
                            ),
                        },
                    }
                    for tc in response.tool_calls
                ],
            }
            messages.append(assistant_msg)

            # Execute all tool calls concurrently
            async def _exec(tc):
                log.debug(
                    "tool call: %s(%s)",
                    tc.name,
                    json.dumps(tc.arguments, ensure_ascii=False)[:200],
                )
                if on_tool_event:
                    await on_tool_event(ToolEvent(name=tc.name, arguments=tc.arguments))
                started = time.monotonic()
                result = await self.tools.execute(tc.name, tc.arguments)
                elapsed = time.monotonic() - started
                log.debug("   → (%.2fs) %s", elapsed, result[:300])
                if on_tool_event:
                    await on_tool_event(ToolEvent(
                        name=tc.name,
                        result_preview=result[:200],
                        is_error=result.startswith("Error:"),
                        duration=elapsed,
                    ))
                return tc, result

            results = await asyncio.gather(
                *[_exec(tc) for tc in response.tool_calls]
            )

            for tc, result in results:
                # Compress tool output based on model tier
                if len(result) > self._output_limit:
                    head = self._output_limit * 2 // 3
                    tail = self._output_limit // 3
                    result = (
                        result[:head]
                        + f"\n\n[... truncated {len(result) - head - tail} chars ...]\n\n"
                        + result[-tail:]
                    )
                # Self-reflection on errors: nudge the LLM to reason about failures
                if result.startswith("Error:"):
                    result = (
                        f"{result}\n\n"
                        "[The tool call failed. Analyze what went wrong "
                        "and try a different approach.]"
                    )
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "name": tc.name,
                        "content": result,
                    }
                )

            # Loop detection: identical consecutive tool calls → nudge
            for tc, _result in results:
                sig = hashlib.md5(
                    json.dumps({"n": tc.name, "a": tc.arguments}, sort_keys=True).encode()
                ).hexdigest()
                self._recent_calls.append(sig)
            # Keep a sliding window of last few signatures
            self._recent_calls = self._recent_calls[-6:]
            if len(self._recent_calls) >= 4:
                last4 = self._recent_calls[-4:]
                if last4[0] == last4[1] == last4[2] == last4[3]:
                    messages.append({
                        "role": "user",
                        "content": (
                            "You have repeated the same tool call multiple times "
                            "with the same result. Try a completely different approach."
                        ),
                    })

        # Max-iteration exhaustion: persist the turn so session history
        # reflects it happened, otherwise the next turn has no memory of it.
        conversation.append({"role": "user", "content": user_message})
        conversation.append({
            "role": "assistant",
            "content": "[Stopped: reached max iterations without completing.]",
        })
        return "Reached maximum iterations. Please try a simpler request."

    def _prune_tool_results(self, messages: list[dict]) -> list[dict]:
        """Return a copy of *messages* with old tool results trimmed.

        Protects the last 3 assistant turns and their tool results.
        Older tool messages get soft-trimmed (head+tail) or replaced
        with a placeholder.  The original list is never mutated.
        """
        # Find positions of the last 3 assistant messages
        asst_indices = [i for i, m in enumerate(messages) if m.get("role") == "assistant"]
        cutoff = asst_indices[-3] if len(asst_indices) >= 3 else 0

        pruned: list[dict] = []
        for i, msg in enumerate(messages):
            if i >= cutoff or msg.get("role") != "tool":
                pruned.append(msg)
                continue
            content = msg.get("content", "")
            if len(content) <= 4000:
                pruned.append(msg)
            elif i >= cutoff - 6:
                # Soft-trim: keep head + tail
                trimmed = content[:1500] + "\n...\n" + content[-1500:]
                pruned.append({**msg, "content": trimmed})
            else:
                # Hard-clear: replace with placeholder
                pruned.append({**msg, "content": "[Old tool result cleared to save context]"})
        return pruned

    async def _summarize_history(self, conversation: list[dict]):
        """Summarize oldest messages in-place to keep context bounded.

        [AgentWebUI patch] 返回本次压缩的统计（成功/失败都返回，异常时 ok=False），
        由 run() 存入 self.last_compaction 再经 bridge 透出前端。
        """
        # Determine how many messages to summarize: enough to drop below
        # compactTargetRatio (默认 50%) of effective context, but at least 6.
        total = estimate_messages_tokens(conversation)
        target = int(self._effective_ctx * self._compact_target_ratio)
        acc, cut = 0, 0
        for i, msg in enumerate(conversation):
            acc += estimate_messages_tokens([msg])
            if acc > total - target:
                cut = max(i, 6)
                break
        if cut < 6:
            cut = min(20, len(conversation) - 4)  # fallback: oldest 20, keep last 4

        to_summarize = conversation[:cut]
        keep = conversation[cut:]
        # [AgentWebUI patch] 统计压缩前后的量，供前端显示"压缩后占比"
        _dropped_tokens = estimate_messages_tokens(to_summarize)
        _kept_tokens = estimate_messages_tokens(keep)

        # Build a tight summarization request
        summary_messages = [
            {
                "role": "system",
                "content": (
                    "Summarize in under 200 words. Keep file paths, error "
                    "messages, code snippets, and key decisions verbatim. "
                    "State what was done and what remains."
                ),
            },
            {
                "role": "user",
                "content": "\n".join(
                    f"[{m['role']}]: {m.get('content', '')[:500]}"
                    for m in to_summarize
                    if m.get("content")
                ),
            },
        ]

        try:
            response = await self.provider.chat(
                summary_messages, tools=None, temperature=0.3
            )
            summary_text = response.content or "Previous conversation context."
        except Exception as e:
            log.warning("Failed to summarize history: %s", e)
            return {
                "ok": False,
                "reason": f"{type(e).__name__}: {e}",
                "summarized_messages": len(to_summarize),
                "kept_messages": len(keep),
                "dropped_tokens": _dropped_tokens,
                "kept_tokens": _kept_tokens,
                "summary_tokens": 0,
                "after_messages": len(conversation),
            }

        # Use role='user' rather than 'system' — the real system prompt is
        # prepended fresh every turn in run(), so a second 'system' entry
        # here would give small models two leading system messages and
        # dilute the constraint-first anchoring they rely on.
        new_conversation = [
            {
                "role": "user",
                "content": f"[Previous context summary]\n{summary_text}",
            },
        ]
        new_conversation.extend(keep)
        conversation.clear()
        conversation.extend(new_conversation)
        return {
            "ok": True,
            "summarized_messages": len(to_summarize),
            "kept_messages": len(keep),
            "dropped_tokens": _dropped_tokens,
            "kept_tokens": _kept_tokens,
            "summary_tokens": estimate_messages_tokens(new_conversation[:1]),
            "after_messages": len(new_conversation),
        }

    async def _call_provider_with_retry(self, messages, tool_defs, on_stream, on_thinking=None):
        """Call the provider with retry + exponential backoff (with jitter) for transient errors."""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                if on_stream:
                    return await self.provider.chat_stream(
                        messages,
                        on_delta=on_stream,
                        tools=tool_defs or None,
                        temperature=self.temperature,
                        on_thinking=on_thinking,
                    )
                return await self.provider.chat(
                    messages,
                    tools=tool_defs or None,
                    temperature=self.temperature,
                )
            except Exception as e:
                transient = (
                    isinstance(e, httpx.HTTPStatusError)
                    and e.response.status_code in _TRANSIENT_CODES
                ) or isinstance(e, (httpx.ConnectError, httpx.ReadTimeout, OSError))
                if transient and attempt < max_retries - 1:
                    wait = (2 ** attempt) + random.uniform(0, 1)  # jitter
                    log.warning(
                        "Transient error, retry %d/%d in %.1fs: %s",
                        attempt + 1, max_retries, wait, e,
                    )
                    await asyncio.sleep(wait)
                    continue
                log.error("Provider error: %s", e)
                return f"Error communicating with LLM: {e}"
